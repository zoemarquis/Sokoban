package modele;
/** Classe qui modélise une case vide. */
public class Vide extends CaseNonDeplacement{
    /** Constructeur d'une case vide. */
    public Vide(){
        super("/");
    } 
}