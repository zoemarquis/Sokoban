package modele;
/** Classe qui modélise une case mur. */
public class Mur extends CaseNonDeplacement{
    /**COnstructeur d'un mur. */
    public Mur(){
        super("#");
    }
}